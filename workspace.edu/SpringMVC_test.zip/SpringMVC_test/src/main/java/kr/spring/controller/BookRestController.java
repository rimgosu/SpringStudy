package kr.spring.controller;

public class BookRestController {

}
